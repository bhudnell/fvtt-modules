# PF1e CR in Combat Tracker
Calculates the approximate CR and APL for actors in the combat encounter


Approximate CR is calculated from NPC actors with the "Hostile" disposition

APL is calculated from PC actors with the "Friendly" disposition